المصدر داخل Madar/. التوثيق docs/visual-redesign-ar.md. إصلاح serial-log race وحالات JIT الفاشلة + تصميم iPhone-inspired. ليست IPA ولا إصلاحاً مثبتاً على جهازك. لا تحذف بيانات الضيف.
