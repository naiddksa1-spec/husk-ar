# مدار: طابع iPhone وإصلاحات مراقبة الإقلاع

النسخة الحالية تستبدل تصميم One UI السابق بطابع iPhone مستقل: graphite/porcelain، wallpaper لؤلؤية متجهية ثابتة، أيقونة مدارية أقل تشبعاً، dock وwidget بمواد SwiftUI الأصلية مع fallback عند Reduce Transparency، إعدادات مجمّعة وأحجام رموز أكثر هدوءاً. ليست تصميم Apple الرسمي أو iPhone 18 موثقاً، ولا تغيّر نظام Android داخل الضيف إلى iOS. اسم مدار وبنية bundle محفوظان. تغييرات التصميم: 11 Swift + 17 PNG + هذا التوثيق، 29 ملفاً.

## إصلاح التعليق
- نقل حذف serial log إلى ما قبل بدء thread الخاص بـQEMU. سابقاً بدأ QEMU قبل أن يحذف tailer الملف؛ قد يظل يكتب إلى inode حُذف اسمه، فلا يعثر المراقب على الملف ولا يتحرك التقدم. إصلاح race محتملة في الكود، وليس إثباتاً أنها سبب مشكلة جهاز المستخدم.
- نشر isRunning كـPublished كي ترى الواجهة توقف QEMU. إغلاق انتظار الإقلاع وعرض سبب عند فشل شرط JIT، بدل العودة الصامتة.
- readiness polling يفحص عمر الجلسة، ويحد أوامر id/getprop بخمس ثوانٍ بدلاً من 30، ويعرض elapsed حقيقياً لا attempt×3. لا يمنح ذلك deadline كاملاً لانتظار mutex؛ ما زال bridge يملك حدوداً ومخاطر تحتاج قياساً.
- إلغاء زيادة النسبة الزمنية الوهمية، وإظهار فتح السجل والعودة للرئيسية بعد دقيقتين دون milestone. هذا تشخيص ومسار خروج وليس ادعاء إقلاع ناجح. الضيف لا يُقتل تلقائياً ولا تُحذف userdata/snapshots.
ملفان إضافيان خارج مجموعة التصميم: QemuRunner.swift وHuskBridgeFS.swift، مع تعديلات تشغيل إضافية في ContentView.swift وBootScreen.swift. الإجمالي مقارنة بالنسخة السابقة: 31 ملفاً.

## تحقق
اختبارات host الأمنية نجحت، و5 assertions بنيوية لترتيب serial cleanup وPublished running وJIT failure/milestone progress نجحت. اختبارا المتصفح نجحا للمعاينة. لا توجد Apple SDK/Swift compiler/iPhone في هذه البيئة، لذلك لا IPA ولا قياس تشغيل ولا ضمان زوال التعليق على الجهاز. تعليق أو توقف JIT trap أثناء debugger attach لا يمكن حله بtimeout UI وحده؛ يلزم سجل وجهاز للاختبار. بقي prewarm الأول متزامناً، ولم يعد كتابة QEMU أو JIT ABI.

## المطلوب على الجهاز
بناء Xcode مع dependencies المناسبة، اختبار cold boot وrestore وفشل JIT وغياب serial log وstop QEMU، ثم مراجعة dock مع keyboard وrotation وVoiceOver وReduce Transparency وReduce Motion. لا تستخدم restart QEMU داخل العملية بعد فشلها دون اختبار دعم إعادة التهيئة.

## التسليم
PDF صور من معاينة React، ليست صور build iOS. preview.html ذاتي الاحتواء مع أسماء تطبيقات وملفات توضيحية. المصدر والمقارنة ونتائج الفحص داخل الحزمة. لم ينجح نشر رابط ClickUp للمعاينة لذا أرفقت HTML. بعض واجهات التقنية القديمة والنصوص ما زالت تستخدم Husk ومكونات سابقة؛ واجهات APK نفسها لم تتغير.
