# Husk: security and startup hardening

تاريخ التعديل: 2026-10-05. هذه حزمة مصدر معدّل، وليست IPA مبنية أو إصداراً مضموناً للإنتاج. التغييرات تقلل مخاطر محددة؛ لا يوجد ادعاء بإزالة كل الثغرات أو بقياس تسريع على iPhone.

## Changes: 18 modified files, 2 added files

| File | Change |
| --- | --- |
| src/app/Husk/AppSource.swift | HTTPS-only source/APK URLs without credentials; downgrade redirect rejection; download/final size checks; HTTP status checks; UUID destinations; synchronous ownership of temporary downloads; retained progress observations; duplicate download prevention; 4-source concurrency; off-main JSON decoding and sorting. Limits: index 64 MiB and 10,000 apps, APK 1 GiB. |
| src/app/Husk/ContentView.swift | Acquire JIT before staging, prevent overlapping evaluations, stage firmware off-main, allow QEMU start with held JIT after debugger detachment. |
| src/app/Husk/JITBootstrap.swift | Serialize prewarm and return quickly after successful acquisition. |
| src/app/Husk/GuestImage.swift | Serialize firmware staging; stream gzip through zlib with CRC/ISIZE validation; reject truncation/trailing data; cap expansion at 8 GiB; validate staged qcow2 magic/minimum size before replacing userdata; preserve old userdata on staging failure. |
| src/app/Husk/HuskBridgeFS.swift | Preserve embedded quotes with POSIX quoting; quote media scanner URI; reject NUL filenames/directories. |
| src/app/Husk/TranslationLayer.swift | Per-attempt explicit warning/consent before in-process native execution, plus guest-install alternative. |
| src/ios-jit/husk-ios-jit.c | Release RX mapping when alias creation or RW protection fails. |
| src/translation-layer/husk-tl-dex.c | DEX structural preflight, bounded ULEB128/strings, table/index/code-item checks, count budgets, instruction-width/register guards, and allocation rollback. |
| src/translation-layer/husk-tl-load.c | Program-header/segment/symbol/GNU-hash bounds; relocation-slot checks; RELR addend/bitmap corrections; initializer-range checks; packed-table limits. |
| src/translation-layer-next/husk-tl-ld.c | PT_LOAD range/capacity checks, bounded dynamic/string/hash tables, symbol indexes and relocations; checked RELR/APS2/resolver addresses and allocation arithmetic. |
| src/translation-layer-next/husk-tl-unity-app.c | Binary XML string-pool/attribute bounds, zero-output protection, strict package-name characters. |
| src/translation-layer-next/husk-tl-xmem.c | Strict TL_XMEM_MIB parsing and checked allocation arithmetic; reject zero/overflowing requests. |
| src/translation-layer-next/husk-tl-jni-cocos.c | Copy preference values under mutex and release caller-owned copies after conversion. |
| src/translation-layer-next/husk-tl-jni-minecraft.c | Same preference lifetime correction. |
| src/translation-layer-next/husk-tl-http.m | HTTP(S) with host only; request validation; streamed 64 MiB response cap; allocation checks; per-request ephemeral sessions. |
| src/translation-layer-next/husk-tl-jni-http.c | Validate upload callback counts; 64 MiB upload cap; checked realloc; report bounded actual body size rather than narrowing untrusted Content-Length; invalidate direct-buffer views before releasing native storage. |
| scripts/build_ios.sh | Fail fast; reject unknown stages before toolchain calls; never stamp failed patch application as successful. |
| scripts/cloud-init/user-data | Disable password SSH/root login; remove known password and console autologin; argv-based launch/install; reject APK outside inbox; do not mark failed Waydroid initialization complete. |
| tests/security/test_hardening.py (new) | Reproducible host tests with sanitizer checks and explicit platform stubs. |
| docs/security-review.md (new) | This change record, test scope, known limitations and device checklist. |

## Run host tests

```sh
python3 tests/security/test_hardening.py
```

Requires Python 3, a host C compiler, and zlib development headers. Tested on Linux/GCC with ASan/UBSan. The harness uses Linux `-no-pie`; adjust that option for Apple tools. DEX, XML and selected ELF production functions are extracted verbatim into host harnesses. ELF symbol resolution is stubbed. Mach time/VM declarations are stubbed for legacy-source syntax checks only. Those checks are not an Apple build, ARM64 loader integration test, Swift test, or complete security verification.

## Performance status

Firmware staging during evaluate and source decoding/sorting moved off MainActor. Sources load with bounded concurrency; successful JIT prewarm does not repeat allocation. No startup-time, FPS, battery or peak-memory benchmark was performed. First JIT acquisition remains synchronous; some existing Start paths still call firmware staging synchronously. Extra ELF/DEX validation and per-request HTTP sessions have costs and require real-APK measurement.

## Unresolved risks and compatibility changes

1. Native APK code runs inside Husk, not a sandbox. Filesystem shims still need root-confined fd-relative path resolution; consent does not prevent malicious native code from accessing process memory/APIs/syscalls. Use the guest for untrusted APKs.
2. DEX is not a full ART verifier. Instruction boundaries, branch semantics, object types, bitmap/array limits, recursion and some arithmetic still need hardening. ELF checks are not a complete verifier of section/overlap/symbol/constructor semantics.
3. Rejected ELF loads can still consume monotonic executable-arena reservations. Do not describe native loading as safe for untrusted content.
4. Repository metadata, manifests and APK publisher signatures are not fully authenticated. HTTPS and an unsigned digest are not publisher verification. Icon URLs are not comprehensively restricted here.
5. ZIP metadata/decompression budgets, guest diagnostics/logging, formatter and remaining network/filesystem shims remain follow-up work.
6. Digest stamps remain caches, not evidence that current multi-GiB files have not changed. Supply-chain downloads/ANGLE/actions are not fully pinned; trusted digests were not invented.
7. The cloud-init changes affect newly generated Waydroid images, not existing downloaded images. The service account and passwordless sudo remain for service compatibility; provide recovery keys via a separate development profile.
8. HTTP ephemeral sessions do not preserve cookies between requests. Direct-buffer views are invalidated after synchronous callbacks finish. Test Unity/Minecraft behavior before production use.
9. URLSession in-flight download limits and redirect behavior need iOS validation in addition to implemented final-size checks.
10. Snapshot validation checks gzip integrity and basic qcow2 magic/minimum size, not the full qcow2 structure. Do not replace a disk while QEMU is using it: this patch does not add a unified QEMU lifecycle/install lock. Stamps and replacement are not a single cross-file transaction.

## Required Apple/device validation

Build with Xcode and compatible dependencies, then test cold/warm start, first interactive UI/frame, and peak memory on the same device/settings. Exercise JIT prewarm/detach/start and allocation failure; source/APK download status/redirect/size/duplicates; gzip truncation/bad CRC/disk-full with old-userdata preservation; snapshot restore; concurrent preference access; native game callbacks; and newly generated cloud-init GUI/agent plus login policy.

No Apple SDK, Swift compiler or iOS device was available. The sandbox has no internet access, so dependencies were not fetched and external hashes were not verified. No IPA was built.

## Build wiring warning

The supplied GitHub workflow copies QEMU from an upstream IPA rather than rebuilding it. The change in `src/ios-jit/husk-ios-jit.c` reaches a binary only when QEMU is rebuilt/integrated from this source. Use the full `scripts/ci_build.sh` pipeline on macOS with the required dependencies for that change; the existing shortcut workflow is not evidence that every changed C file was compiled.
