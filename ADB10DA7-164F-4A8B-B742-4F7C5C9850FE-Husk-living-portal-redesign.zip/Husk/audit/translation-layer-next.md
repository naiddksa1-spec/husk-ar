# Translation-layer-next audit

Scope: only `src/translation-layer-next/*` was edited. Existing changes outside this scope were left untouched.

## Applied fixes

| File | Function/area | Problem | Fix and rationale |
|---|---|---|---|
| `husk-tl-audio.c` | `open_queue` | AudioQueue buffer/ring allocation and enqueue/start return values were ignored. A failed allocation could dereference a null buffer or leave a half-created queue; a failed start left `A.q` non-null and the next write could use invalid state. | Validate sample rate/channel count and ring-size arithmetic; check every AudioQueue operation; dispose and free all partially-created state on failure. |
| `husk-tl-audio.c` | `sleep_for` | The old floating-point conversion could produce an invalid `timespec` (`tv_nsec >= 1e9`) for larger writes, and interrupted sleeps shortened pacing. | Compute seconds/remainder with integer arithmetic, reject non-positive inputs, and retry `EINTR`. |
| `husk-tl-bionic-pthread.c` | `b_sem_timedwait` | A spurious condition-variable wake reused the original relative timeout, extending the guest’s absolute deadline indefinitely. | Recompute the remaining relative interval from `CLOCK_REALTIME` on every loop iteration. |
| `husk-tl-bionic-pthread.c` | `b_sigmask` | The old conversion copied only four bytes into Darwin’s `sigset_t`; the remaining representation was uninitialized and signal masks could be corrupted. Invalid `how` values were also silently treated as `SIG_SETMASK`. | Build/read the Darwin set through `sigemptyset`, `sigaddset`, and `sigismember`, and reject unsupported operations. |
| `husk-tl-dexindex.c` | DEX readers and `tl_dexidx_open` | Header/table offsets, string data, ULEB128 strings, and class data were trusted. Truncated/corrupt DEX input could read out of bounds; stored-entry copying also lacked an allocation check and several error paths leaked the open ZIP mapping. | Add checked range reads, bounded ULEB parsing, NUL validation, descriptor-safe comparison/hash handling, complete table-span validation, allocation checks, and ZIP cleanup on failure. |
| `husk-tl-jni.c` | `lookup_method` | Cached JNI method IDs were kept in a per-class linear array and every lookup acquired the global JNI lock; repeated `GetMethodID`/call setup paid an avoidable lock and string-scan cost. Concurrent misses could also create duplicate method records. | Add per-class open-addressed method cache, recheck under the lock before insertion, and add a thread-local last-method fast path that avoids the global lock on repeated calls. The linear array remains as an OOM fallback. |
| `husk-tl-jni.c` | pending exception ownership | `tl_jni_clear`/`ExceptionClear` discarded pending exceptions without releasing them, while `jni_Throw` did not retain the supplied exception reference; repeated throws leaked or could leave a dangling pending pointer. | Centralize replacement of the thread-local pending exception, retain exceptions passed to `Throw`, and release the previous pending exception on replacement/clear. |
| `husk-tl-ld.c` | `map_library` ELF input validation | Program/section-header range checks used addition expressions vulnerable to integer wraparound; segment file/memory bounds and the dynamic-section location were not validated before copying/parsing. | Use subtraction-based bounds checks, reject `p_memsz < p_filesz`/address overflow, validate dynamic data lies in the planned image, check allocations, and use overflow-safe section/segment checks. |
| `husk-tl-xmem.c` | `open_platform`, `tl_xmem_alloc`, `tl_xmem_delta` | Size rounding/doubling could overflow, allocation subtraction assumed `used <= size`, and subtracting pointers from separate mappings is not defined by C. | Reject overflowing sizes, guard the remaining-capacity subtraction, and calculate the mapping delta through integer addresses. |

## Verification

Passed without warnings for the requested Linux syntax-check setup:

```text
gcc -std=gnu11 -fsyntax-only -Wall -Wextra -Isrc/translation-layer -Isrc/translation-layer-next \
  husk-tl-a64.c husk-tl-dexindex.c husk-tl-jni.c husk-tl-ld.c husk-tl-va.c husk-tl-xmem.c
```

Several JNI companion files also parsed; the full requested sweep cannot complete in this Linux sandbox because `husk-tl-jni-minecraft.c` includes Apple `sys/sysctl.h`, and other Darwin-only files require Apple SDK/framework headers. `git diff --check` passed.

## Recommendations not applied

1. **Run on an iOS device with AudioQueue diagnostics enabled.** `on_buffer` still copies samples while holding `A.mu`, and `tl_audio_set_paused` calls AudioQueue control functions while holding the same mutex. This avoids allocations in the callback today, but a device test should verify that AudioQueue never invokes the callback synchronously during pause/start; if it does, move queue control outside the lock and replace the ring with an SPSC/atomic design.
2. **Keep frame capture disabled in production.** When `frame_dir` is configured, `w_eglSwapBuffers` intentionally performs `glReadPixels` and allocates a full RGBA frame per captured frame. This is diagnostic behavior, not a safe 60-FPS path; device profiling should confirm no production configuration enables it.
3. **Harden all dynamic-table consumers in the ELF loader.** The mapping checks now reject malformed program/section layouts, but dynamic tags (`DT_STRTAB`, hash tables, relocation arrays, and init arrays) are still trusted to point inside the mapped image. APK ELF files are normally trusted; a fully hostile-ELF threat model needs image-range helpers threaded through `parse_dynamic`, symbol lookup, and relocation parsing.
4. **Audit JNI field ownership.** JNI object fields currently store `jvalue` pointers without a general retain/release policy. A long-running workload that repeatedly stores/replaces object fields can leak references, while a caller that releases a stored object can create a dangling field. Fixing this requires a deliberate local/global-reference ownership model and should be tested against all HLE object lifetimes.
5. **Device-test ABI-sensitive pthread behavior.** Darwin-only `pthread_cond_timedwait_relative_np`, thread naming, signal numbering, and bionic object sizes need an arm64 iOS build/runtime test; Linux syntax checking cannot validate those ABI assumptions.
