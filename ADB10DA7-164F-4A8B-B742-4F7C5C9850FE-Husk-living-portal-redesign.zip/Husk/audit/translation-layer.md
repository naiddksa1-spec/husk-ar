# Husk translation-layer audit

## Scope and baseline

Reviewed `docs/04-translation-layer.md`, the translation-layer C sources and headers, the translation-layer tests, and the existing in-scope diff. Changes were limited to `src/translation-layer/*.c` and the requested report directory; no tests or tools required source changes.

## Changes applied

| File / function | Problem | Fix | Verification |
|---|---|---|---|
| `husk-tl-json.c`: `put` | `len + n + 1` and doubling the capacity could wrap, causing undersized allocation and a subsequent write past the buffer. | Checked the addition and capacity doubling, including the `SIZE_MAX` edge case; allocation failure remains sticky. | Linux `gcc -std=gnu11 -O2 -Wall -Wextra -Werror -fsyntax-only`; ASan/UBSan malformed UTF-8 harness. |
| `husk-tl-json.c`: `utf8_len` / `quoted` | A truncated multi-byte UTF-8 sequence was inspected beyond the NUL-terminated input. | Track remaining bytes and reject incomplete sequences; replacement-byte path advances correctly. | ASan/UBSan harness produced `["?"]` for a truncated sequence. |
| `husk-tl-zip.c`: `tl_zip_data` | Local-header name/extra lengths were added to the local offset without an explicit overflow-safe check. | Checked the addition before forming the data offset. | Linux syntax check; ASan/UBSan ZIP harness. |
| `husk-tl-zip.c`: `tl_zip_data` | Valid empty deflated entries could fail because zlib received zero output space and never consumed the end marker. | Provide a one-byte output slot for zero-size output. | Generated empty deflated ZIP; ASan/UBSan harness returned success and length 0. |
| `husk-tl-res.c`: primitive readers and string pools | Index arithmetic such as `i + 3`, `chunk + size`, pool offset addition, and UTF-16 allocation-size multiplication could wrap before bounds checks. | Replaced checks with subtraction-based bounds checks and validated pool/table/string sizes before access or allocation. | Linux syntax check; malformed random resource buffers under ASan/UBSan. |
| `husk-tl-blit.c`: draw/fill/opaque test | Invalid dimensions, strides, non-finite coordinates, and image-size multiplication could produce invalid pointer arithmetic or overflow. | Validate dimensions/stride/finite coordinates and multiplication bounds. | Linux syntax check. |
| `husk-tl-elf.c`: address conversion/page planning/table counting | Vaddr/file-offset and RELRO end arithmetic could overflow; relocation-table loop underflowed when `size < entsize`; NULL report/data handling was unsafe. | Added checked additions, RELRO overflow rejection, `entsize > size` rejection, and early NULL validation before `memset`. | Linux syntax check and planner test; all planner cases passed. |
| `husk-tl-framework.c`: bitmap allocation and ArrayList growth | Bitmap dimensions from app/resource data could overflow `width * height * 4`; unchecked `realloc` could lose the old list. | Added checked `bitmap_alloc`, used it in PNG/crop/scale/creation paths, checked object allocation, and used a temporary pointer for list growth. | Linux syntax check; Apple-only branches reviewed for CoreGraphics ownership and integer conversions. |
| `husk-tl-scan.c`: `husk_tl_scan` | NULL paths/negative counts and signed DEX-byte accumulation were not guarded. | Normalize invalid arguments, reject NULL path entries, and saturate count/byte totals. | Linux syntax check; ASan/UBSan scan harness on random input. |
| `husk-tl-prefs.c`: save/attach | Path-length addition and path duplication failure were unchecked; an unbounded preference line could cause excessive allocation. | Check path-size arithmetic and `strdup`; reject lines over 1 MiB. | Linux syntax check. |
| `husk-tl-dex.c`: bounded reads and `parse_dex_buffer` | ULEB128 decoding could run off malformed DEX data; header/table/code offsets and allocation sizes were trusted. | Bounded five-byte ULEB decoder, DEX header/table/file-size validation, bounded code-item validation, ID/proto checks, and allocation-failure handling. | Linux syntax checks for requested files; malformed-parser review and ASan/UBSan resource/scan harnesses. The DEX source itself requires Apple headers in this checkout and was reviewed rather than Linux-compiled. |
| `husk-tl-load.c`: loader bounds and relocations | Segment offset addition, unterminated dynamic strings, ELF program-header arithmetic, relocation target arithmetic, and dynamic-table file range were insufficiently checked. | Added checked arithmetic, NUL-termination validation, ET_DYN validation, image-range validation for relocation targets, signed-addend overflow handling, and dynamic-table bounds checks. | Apple-only loader path reviewed; Linux compilation is unavailable because of Mach/iOS headers. |

## Required verification

All nine requested Linux-compilable files passed:

```text
gcc -std=gnu11 -O2 -Wall -Wextra -Werror -Isrc/translation-layer -fsyntax-only
```

Files checked:

- `husk-tl-blit.c`
- `husk-tl-elf.c`
- `husk-tl-json.c`
- `husk-tl-prefs.c`
- `husk-tl-probe.c`
- `husk-tl-res.c`
- `husk-tl-scan.c`
- `husk-tl-shim.c`
- `husk-tl-zip.c`

The planner test was rebuilt and passed all cases:

```text
ok   4k layout on 4k pages: RXRW
ok   4k layout on 16k pages: !
ok   16k layout on 16k pages: RXRW
ok   code with RELRO on one page: XW
ok   same, without RELRO: !W
ok   RELRO in the middle: XWRW
ok   bss spans pages: XWWW
ok   hole: X--W
ok   bad layouts refused
all passed
```

Additional throwaway ASan/UBSan checks covered malformed UTF-8 JSON, empty deflated ZIP data, random resource buffers, and random scan input.

## Apple-only review limitations

The sandbox has the requested GCC/zlib environment but not the iOS/Mach/CoreGraphics SDK headers needed to syntax-compile `husk-tl-dex.c`, `husk-tl-framework.c`, or `husk-tl-load.c` as Apple builds. Their edited hunks were re-read manually. The reviewed CoreGraphics changes preserve the existing `CGImageRef` ownership pattern and guard bitmap dimensions before conversion to `int`; the loader changes use existing fixed-width types and do not alter public APIs.

## Recommendations not applied

1. Add a checked, SDK-backed Apple CI build for all translation-layer files, including `-Wconversion`/sanitizer configurations where practical.
2. Add a bounded DEX class-data reader that propagates malformed-ULEB status instead of treating a truncated value as zero and continuing with an empty class definition.
3. Store and validate dynamic-symbol counts in the runtime loader before indexing `symtab` from relocation symbol indices; GNU-hash chain traversal should also have an explicit mapped-table bound.
4. Add a global decompression/output budget across an APK scan, not only a per-entry ZIP limit, to reduce aggregate ZIP-bomb memory pressure.
5. Add regression fixtures for empty deflated ZIP entries, truncated UTF-8, overflowing DEX tables, overflowing ELF addresses, malformed resource string pools, and huge bitmap dimensions.
6. Replace linear resource-name scans and repeated ZIP entry scans with indexes if profiling confirms they are hot for large APKs.
