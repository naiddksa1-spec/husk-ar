# Husk iOS/JIT audit

Scope reviewed: `src/ios-jit/*`, `tests/husk_display_probe.c`, and the three
requested build scripts. The build scripts already pass `-O2` through the iOS
cross files, use Meson `--buildtype=release`, configure QEMU without debug info,
and build ANGLE with Xcode `Release`; no conservative flag change was justified.

## Applied changes

- [`src/ios-jit/husk-audio.c`](../src/ios-jit/husk-audio.c), `husk_write()` and
  `husk_audio_pull()` — the ring producer/consumer used per-frame/channel loops,
  allowing unnecessary CPU work in the audio path. They now copy each contiguous
  ring segment with `memcpy()`. The producer also rejects a null/empty source and
  clamps a corrupt/full `w-r` distance instead of allowing `free_frames` to
  underflow and overwrite unread samples.
- [`src/ios-jit/husk-audio.c`](../src/ios-jit/husk-audio.c), audio counters —
  `frames_in` and `underruns` were plain 64-bit fields written from one callback
  thread and read from another. They now use QEMU atomic fetch/add and reads,
  removing the C data race while preserving lock-free render behavior. Negative
  frame counts and a null destination are rejected in the app pull API.
- [`src/ios-jit/husk-display.c`](../src/ios-jit/husk-display.c), graphics
  callbacks — `gfx_update`, surface switch, and format checks no longer perform
  `os_log`/`fprintf`/`fflush` while the BQL is held. Those synchronous operations
  were on the frame callback path and could stall vCPUs. The sequence counter is
  still updated and exposed for diagnostics; startup/UI diagnostics remain.
- [`src/ios-jit/husk-display.c`](../src/ios-jit/husk-display.c), display state and
  input counters — the init flag and UI pointer/key counters are now accessed
  atomically. The timestamp baseline used by diagnostics is also initialized
  with an atomic compare/exchange rather than a racy static write.
- [`src/ios-jit/husk-display.c`](../src/ios-jit/husk-display.c),
  `husk_display_send_pointer()`, `husk_display_send_key()`, and
  `husk_display_request_update()` — these APIs previously unconditionally took
  the BQL. Calling one from an already-BQL-held QEMU callback could deadlock or
  trip QEMU's non-recursive-BQL assertion. They now test `bql_locked()` and only
  lock/unlock when entering from another thread; BQL-held calls also avoid their
  diagnostic writes.
- [`src/ios-jit/husk-display-gl.c`](../src/ios-jit/husk-display-gl.c), GL update
  path — the thumbnail diagnostic used repeated synchronous `glReadPixels()`
  readbacks on QEMU's BQL thread (18 full-width rows per sample). It is now
  compile-time opt-in via `HUSK_GL_DIAGNOSTICS` and disabled by default. GL frame
  counters use QEMU atomic operations because the update thread and UI counter
  reader are different threads.
- [`src/ios-jit/husk-display-gl.c`](../src/ios-jit/husk-display-gl.c), GL bind
  failure paths — shader resources are freed when no console exists or console 0
  is not graphical. The latter is rejected before handing the console to QEMU's
  GL listener machinery, avoiding the documented non-graphical-console crash
  path.
- [`src/ios-jit/husk-ios-jit.c`](../src/ios-jit/husk-ios-jit.c), prewarm/allocate
  lifecycle — the prewarm state and mapping handoff were unsynchronized. A
  pthread mutex now serializes prewarm and QEMU allocation, with the completion
  flag set only after allocation finishes; this prevents a concurrent allocator
  from observing “done” before the mapping exists and avoids a second trap.
- [`src/ios-jit/husk-ios-jit.c`](../src/ios-jit/husk-ios-jit.c), JIT mapping
  validation/error paths — zero and non-16-KiB-aligned requests are rejected;
  when `vm_remap()` or `vm_protect()` fails, the debugger-provided RX mapping is
  now deallocated along with any RW alias. This closes the failure-path Mach VM
  leaks.
- [`src/ios-jit/husk-ios-jit.c`](../src/ios-jit/husk_ios_jit_mapjit_works()`)
  — the signal jump buffer and running flag are thread-local, so a fault on an
  unrelated thread cannot longjmp through another thread's probe state. If a
  guarded write faults after APRR write protection was disabled, the recovery
  path re-enables it before returning.
- [`tests/husk_display_probe.c`](../tests/husk_display_probe.c) — duration input
  now uses checked `strtol()` parsing and rejects non-positive/overflowing
  values, avoiding `seconds * 10` overflow and accidental zero-length runs.
  QEMU argv allocation and each `strdup()` are checked and cleaned up on failure.

## Verification

- `gcc -std=gnu11 -fsyntax-only -Wall -Wextra tests/husk_display_probe.c` passed.
- `git diff --check` passed.
- Full compilation was not possible in this sandbox because the repository does
  not contain the QEMU 10.0 or Apple/iOS headers required by the scoped C files;
  device-only JIT, EGL/ANGLE, BQL, and signal behavior remains unverified here.

## Recommendations not applied

1. `husk_display_lock_frame()` intentionally holds `husk.lock` while the caller
   uploads pixels. That prevents a surface replacement from invalidating the
   borrowed pointer, but a slow UI/Metal upload can block the QEMU display
   callback (and therefore the BQL). Fixing it safely needs an ownership protocol
   outside this scope—e.g. an immutable/refcounted surface snapshot or a
   double-buffered copy—and should be measured on device before changing it.
2. The GL native-texture presenter callback crosses from QEMU's display callback
   into app/Metal code. Its thread affinity and the lifetime promised for
   `ScanoutTextureNative.handle` need confirmation against the exact virgl/ANGLE
   build and device. Moving it to another queue without a retained texture would
   be unsafe, so no speculative change was made.
3. `husk_display_gl_create()` has no public teardown operation. If EGL creation
   succeeds but probing/binding later falls back to software, the EGL display,
   context, and surface may remain allocated until process exit. A teardown API
   should be added only after confirming QEMU/ANGLE ownership rules for
   `qemu_egl_display` and the CAMetalLayer.
4. Audio voice reinitialization resets ring indices while callbacks may be in
   flight. The existing lifecycle normally stops the voice first, but this needs
   an on-device stress test (rapid guest stream open/close) or an explicit
   producer-stop handshake before adding a lock to the real-time callback.
5. The JIT changes require an iOS build/device check for the exact `vm_deallocate`
   behavior of the debugger-created RX allocation, QEMU's `qatomic_fetch_add`
   availability for 64-bit counters, and the fork's `qemu_gl_fini_shader()` API.

## Reviewer overrides

- **husk-display.c:** restored the first-5 `gfx_update` / `gfx_switch` and the `gfx_check_format` log lines (one-off boot diagnostics, the "is the guest alive" signal). Only the recurring every-600-frames logging under the BQL is gone.
- **husk-ios-jit.c:** removed the new "refuse non-16K-aligned size" check; it could reject a JIT allocation that worked before. Only a zero-size request is refused now.
