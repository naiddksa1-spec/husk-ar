# ملخص التحسينات (Husk)

كل التعديلات صغيرة وموضعية، بدون إعادة كتابة للمعمارية. التفاصيل الكاملة لكل تعديل (الملف، الدالة، المشكلة، الحل) موجودة في الملفات الإنجليزية بنفس المجلد:
swift.md · ios-jit.md · translation-layer.md · translation-layer-next.md

## البطء
- إيقاف glReadPixels الدوري في مسار GL (كان يوقف الـ GPU كل 600 فريم وهو ماسك الـ BQL).
- إزالة اللوغ المتكرر داخل callbacks العرض اللي بتشتغل والـ BQL ماسوك (بقي أول 5 أسطر للتشخيص بس).
- الصوت: نسخ الـ ring buffer بـ memcpy بدل لوب لكل عيّنة.
- JNI: جدول hash + كاش لكل thread لـ GetMethodID بدل بحث خطي بـ strcmp.
- الواجهة: فك أيقونات التطبيقات خارج الـ main thread، نسخ الـ APK، تحميل الكتالوج، تجهيز الـ firmware، وفك فهرس F-Droid كلها بقت في الخلفية.
- إعادة استخدام MTLRenderPassDescriptor بدل إنشائه كل فريم.

## الأخطاء
- تقوية parsers للمدخلات غير الموثوقة (ZIP, ELF, DEX, resources.arsc, JSON, gzip): overflow في الأحجام وقراءات خارج الحدود.
- deadlock محتمل لو اتنادى bql_lock وهو ماسوك أصلًا (لمس/كيبورد).
- تسريب ذاكرة JIT عند فشل vm_remap، وتسريب FileHandle، وobservers ما بتتشالش.
- sem_timedwait كان بيمدّ المهلة بعد كل spurious wakeup.
- تحويل sigset بين bionic و Darwin كان بيفترض شكل داخلي خاص بـ Darwin.
- ملكية الاستثناء المعلّق في JNI (تسريب/مؤشر معلّق).
- ZIP entries فاضية ومضغوطة كانت بتترفض بالغلط.

## التحقق
- ملفات C اللي بتتبني على Linux عدّت بـ -Wall -Wextra -Werror، واختبار page planner عدّى كله، وفيه fuzz بـ ASan/UBSan على الـ parsers.
- مفيش Swift compiler ولا Xcode ولا جهاز iOS في البيئة دي، يعني كود Swift و Darwin اتراجع يدويًا بس. لازم تبني في Xcode/CI وتجرب على جهاز.
