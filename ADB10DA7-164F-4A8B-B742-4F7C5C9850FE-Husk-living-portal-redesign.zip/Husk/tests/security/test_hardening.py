#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Host regression checks. Run: python3 tests/security/test_hardening.py

Compile selected production C functions verbatim under ASan/UBSan. This does
not substitute for the full Apple build or device/JNI/concurrency integration.
Requires Python 3, a host C compiler and zlib development headers.
"""
import ast
import os
from pathlib import Path
import re
import shlex
import struct
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
CC = shlex.split(os.environ.get("CC", "cc"))
CFLAGS = ["-std=gnu11", "-O1", "-g", "-Wall", "-Wextra",
          "-fsanitize=address,undefined", "-fno-omit-frame-pointer", "-no-pie"]
INCLUDES = ["-I" + str(ROOT / "src/translation-layer"),
            "-I" + str(ROOT / "src/translation-layer-next")]
COMMON = "#include <assert.h>\n#include <stdint.h>\n#include <stdbool.h>\n#include <stddef.h>\n#include <stdlib.h>\n#include <stdio.h>\n#include <string.h>\n"


def run(args, **kwargs):
    subprocess.run(args, check=True, **kwargs)


def function(source, name):
    # Definitions here have their opening brace on the following line.
    match = re.search(r"^static [^\n]*\b" + re.escape(name) +
                      r"\([^\n]*\)\n\{", source, re.M)
    if not match:
        raise AssertionError("Production function not found: " + name)
    start = source.index("{", match.start())
    depth = 1
    end = start + 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[match.start():end] + "\n"


def build(directory, name, source, extra=()):
    path = directory / (name + ".c")
    path.write_text(source)
    binary = directory / name
    run(CC + CFLAGS + INCLUDES + [str(path)] + list(extra) + ["-o", str(binary)])
    return binary


def test_dex(directory):
    source = (ROOT / "src/translation-layer/husk-tl-dex.c").read_text()
    header = source[source.index("typedef struct {"):source.index("} dex_header;") + len("} dex_header;")]
    names = ["dex_range", "dex_uleb", "dex_u32", "dex_code_valid",
             "dex_preflight", "dex_instruction_valid"]
    harness = COMMON + header + "\n" + "".join(function(source, n) for n in names)
    harness += r'''
int main(void) {
    uint8_t *data = calloc(1, 256); assert(data);
    dex_header *h = (dex_header *)data;
    memcpy(h->magic, "dex\n035", 8);
    h->header_size = sizeof(*h); h->file_size = 256;
    h->endian_tag = 0x12345678; h->data_off = 112; h->data_size = 144;
    assert(dex_preflight(data, 256));
    /* Original reported heap overflow: a class definition crossing EOF. */
    h->class_defs_off = 240; h->class_defs_size = 1;
    assert(!dex_preflight(data, 256));
    h->class_defs_off = 0; h->class_defs_size = 0;
    h->string_ids_off = UINT32_MAX; h->string_ids_size = UINT32_MAX;
    assert(!dex_preflight(data, 256));
    h->string_ids_off = 0; h->string_ids_size = 0;
    uint8_t leb[] = {0xff,0xff,0xff,0xff,0xff};
    const uint8_t *p = leb; uint32_t val;
    assert(!dex_uleb(&p, leb + sizeof(leb), &val));
    p = leb; assert(!dex_uleb(&p, leb + 1, &val));
    uint16_t bad_width[] = {0x0018, 0};
    assert(!dex_instruction_valid(bad_width, 2, 2));
    uint16_t bad_register[] = {0xff02, 0};
    assert(!dex_instruction_valid(bad_register, 2, 2));
    uint16_t bad_invoke[] = {0xf06e, 0, 0};
    assert(!dex_instruction_valid(bad_invoke, 3, 16));
    uint16_t good[] = {0x0013, 1};
    assert(dex_instruction_valid(good, 2, 1));
    assert(!dex_instruction_valid(good, 1, 1));
    for (unsigned i = 0; i < 10000; i++) {
        uint8_t copy[256]; memcpy(copy, data, sizeof(copy));
        size_t off = (i * 37u) % sizeof(copy);
        copy[off] ^= (uint8_t)((i * 71u) | 1);
        (void)dex_preflight(copy, sizeof(copy));
    }
    free(data); puts("PASS DEX structural/operand guards and 10000 mutations");
    return 0;
}
'''
    run([str(build(directory, "dex_guards", harness))])


def manifest(package=b"com.example.safe"):
    strings = [b"package", package]
    payload = b""
    offsets = []
    for text in strings:
        assert len(text) < 128
        offsets.append(len(payload))
        payload += bytes([len(text), len(text)]) + text + b"\0"
    pool = struct.pack("<HHI5I", 1, 28, 36 + len(payload), 2, 0, 0x100, 36, 0)
    pool += struct.pack("<2I", *offsets) + payload
    element = bytearray(56)
    struct.pack_into("<HHI", element, 0, 0x102, 16, len(element))
    struct.pack_into("<3H", element, 24, 20, 20, 1)
    struct.pack_into("<3I", element, 36, 0xffffffff, 0, 1)
    return struct.pack("<HHI", 3, 8, 8 + len(pool) + len(element)) + pool + element


def test_xml(directory):
    source = (ROOT / "src/translation-layer-next/husk-tl-unity-app.c").read_text()
    xml = source[source.index("static uint32_t rd32("):]
    harness = COMMON + '#include "husk-tl-internal.h"\n' + xml
    harness += r'''
int main(int argc, char **argv) {
    assert(argc == 4);
    char out[64] = {0};
    bool ok = husk_unity_package_name(argv[1], out, strtoul(argv[2], NULL, 10));
    assert(ok == (atoi(argv[3]) != 0));
    if (ok) assert(!strcmp(out, "com.example.safe"));
    uint8_t pool[128] = {0};
    for (size_t len = 0; len < sizeof(pool); len++)
        assert(!pool_string(pool, len, UINT32_MAX, out, sizeof(out)));
    assert(!pool_string(pool, sizeof(pool), 0, out, 0));
    return 0;
}
'''
    binary = build(directory, "manifest_guards", harness,
                   [str(ROOT / "src/translation-layer/husk-tl-zip.c"), "-lz"])
    valid = manifest()
    cases = [(valid, 64, True), (valid, 0, False), (valid, 5, False),
             (manifest(b"../outside"), 64, False)]
    cases += [(valid[:n], 64, False) for n in range(len(valid))]
    for i, (data, out_len, expected) in enumerate(cases):
        apk = directory / ("xml-" + str(i) + ".apk")
        with zipfile.ZipFile(apk, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("AndroidManifest.xml", data)
        run([str(binary), str(apk), str(out_len), str(int(expected))])
    print(f"PASS binary XML guards: {len(cases)} real ZIP cases")


def test_xmem(directory):
    harness = COMMON + '#include "husk-tl-xmem.h"\n' + r'''
int main(void) {
    char err[160]; uint8_t *rx = NULL, *rw = NULL;
    assert(!tl_xmem_alloc(SIZE_MAX, &rx, &rw));
    assert(!tl_xmem_alloc(0, &rx, &rw));
    assert(!tl_xmem_contains(NULL)); assert(!tl_xmem_is_rx(NULL));
    assert(tl_xmem_delta() == 0);
    setenv("TL_XMEM_MIB", "-1", 1);
    assert(!tl_xmem_open(4096, err, sizeof(err)));
    assert(strstr(err, "invalid TL_XMEM_MIB"));
    setenv("TL_XMEM_MIB", "999999999999999999999999999", 1);
    assert(!tl_xmem_open(4096, err, sizeof(err)));
    unsetenv("TL_XMEM_MIB");
    assert(!tl_xmem_open(SIZE_MAX, err, sizeof(err)));
    assert(strstr(err, "overflow"));
    puts("PASS executable-memory arithmetic guards");
    return 0;
}
'''
    binary = build(directory, "xmem_guards", harness,
                   [str(ROOT / "src/translation-layer-next/husk-tl-xmem.c"), "-lpthread"])
    run([str(binary)])

def test_elf(directory):
    source = (ROOT / "src/translation-layer-next/husk-tl-ld.c").read_text()
    declarations = source[source.index("typedef struct { uint8_t e_ident"):
                          source.index("static struct {\n    pthread_mutex_t lock;")]
    harness = COMMON + '#include "husk-tl-ld.h"\n#include "husk-tl-internal.h"\n#include "husk-tl-xmem.h"\n' + declarations
    harness += re.search(r"^static inline const void \*at[^\n]+", source, re.M).group(0) + "\n"
    for name in ["image_range", "table_capacity", "count_dynsyms", "parse_dynamic", "image_addr"]:
        harness += function(source, name)
    # Isolate relocation destinations from platform symbol lookup/execution.
    harness += r'''
static void tl_log_line(const char *fmt, ...) { (void)fmt; }
static uint64_t bind_symbol(tl_lib *L, uint32_t i, bool *bad) {
    (void)L; (void)i; *bad = true; return 0;
}
'''
    harness += function(source, "reloc_one")
    harness += r'''
int main(void) {
    uint8_t *memory = calloc(1, PAGE); assert(memory);
    uint8_t flag = TL_PAGE_R | TL_PAGE_W;
    elf_phdr ph = { .p_type = PT_LOAD_, .p_vaddr = 0x1000,
        .p_filesz = 4096, .p_memsz = 8192 };
    tl_lib L = { .rw = memory, .rx = memory, .base_vaddr = 0x1000,
        .npages = 1, .pflags = &flag, .phdr = &ph, .phnum = 1,
        .symtab = 0x1100, .strtab = 0x1300, .strsz = 32, .sysv_hash = 0x1400 };
    assert(image_range(&L, 0x1000, 8));
    assert(!image_range(&L, UINT64_MAX, 8));
    assert(!image_range(&L, 0x0fff, 8));
    assert(!image_range(&L, 0x3000, 1));
    assert(table_capacity(&L, 0x2000) == 0);
    uint32_t *sysv = (uint32_t *)(memory + 0x400);
    sysv[0] = 1; sysv[1] = 2; sysv[2] = 1;
    assert(count_dynsyms(&L) == 2);
    sysv[0] = UINT32_MAX; assert(count_dynsyms(&L) == 0);
    sysv[0] = 1; sysv[1] = UINT32_MAX; assert(count_dynsyms(&L) == 0);
    L.sysv_hash = 0; L.gnu_hash = 0x1fe0;
    uint32_t *gnu = (uint32_t *)(memory + 0xfe0);
    gnu[0] = 1; gnu[1] = 1; gnu[2] = 1; gnu[3] = 5;
    gnu[6] = 1; gnu[7] = 1;
    assert(count_dynsyms(&L) == 2);
    gnu[7] = 0; assert(count_dynsyms(&L) == 0);
    gnu[7] = 1; gnu[3] = 32; assert(count_dynsyms(&L) == 0);
    gnu[3] = 5; gnu[2] = UINT32_MAX; assert(count_dynsyms(&L) == 0);
    assert(!reloc_one(&L, UINT64_MAX, R_RELATIVE, 0, 0x1000));
    assert(!reloc_one(&L, 0x0ff8, R_RELATIVE, 0, 0x1000));
    assert(!reloc_one(&L, 0x1001, R_RELATIVE, 0, 0x1000));
    assert(!reloc_one(&L, 0x1000, R_RELATIVE, 0, -1));
    assert(reloc_one(&L, 0x1000, R_RELATIVE, 0, 0x1100));
    assert(*(uint64_t *)memory == (uint64_t)(uintptr_t)(memory + 0x100));
    assert(!reloc_one(&L, 0x1000, R_IRELATIVE, 0, 0x1100));
    assert(!parse_dynamic(&L, 0x2000, 16));
    elf_dyn *dyn = (elf_dyn *)(memory + 0x500);
    dyn[0].d_tag = 11; dyn[0].d_val = 1;
    assert(!parse_dynamic(&L, 0x1500, 32));
    dyn[0].d_val = sizeof(elf_sym); dyn[1].d_tag = 0;
    assert(parse_dynamic(&L, 0x1500, 32));
    free(memory);
    puts("PASS ELF ranges, hash bounds, dynamic table and relocation slots (symbol resolver stubbed)");
    return 0;
}
'''
    run([str(build(directory, "elf_guards", harness))])


def test_scripts():
    count = 0
    for script in sorted((ROOT / "scripts").glob("*.sh")):
        run(["bash", "-n", str(script)])
        count += 1
    for script in sorted((ROOT / "scripts").glob("*.py")):
        ast.parse(script.read_text(), filename=str(script))
    cloud = (ROOT / "scripts/cloud-init/user-data").read_text()
    # Extract embedded executable bodies without needing a YAML dependency.
    bodies = re.findall(r"^    content: \|\n((?:      .*\n|\n)+)", cloud, re.M)
    executable = 0
    for body in bodies:
        body = "\n".join(line[6:] if line.startswith("      ") else line
                         for line in body.splitlines())
        if body.startswith("#!/usr/bin/env python3"):
            ast.parse(body)
            executable += 1
        elif body.startswith("#!/bin/bash") or body.startswith("#!/bin/sh"):
            run(["bash", "-n"], input=body, text=True)
            executable += 1
    result = subprocess.run(["bash", str(ROOT / "scripts/build_ios.sh"), "nonsense"],
                            capture_output=True, text=True)
    assert result.returncode == 2 and "Unknown build stage" in result.stderr
    assert "plain_text_passwd" not in cloud and "--autologin" not in cloud
    assert '["waydroid", "app", "launch", pkg]' in cloud
    assert '["waydroid", "app", "install", path]' in cloud
    # Exercise the exact POSIX quoting expression used by AndroidHost.quote.
    for value in ["normal", "a'b", "$(printf hacked)", "x; printf hacked", "a\nb", "a b"]:
        quoted = "'" + value.replace("'", "'\"'\"'") + "'"
        result = subprocess.run(["sh", "-c", "printf '%s' " + quoted],
                                capture_output=True, text=True, check=True)
        assert result.stdout == value
    print(f"PASS {count} shell scripts, Python sources, {executable} cloud-init executable bodies, stage rejection and shell quoting")

def test_host_syntax(directory):
    # The legacy sources include Mach time declarations even on host-only code
    # paths. Stub declarations ONLY for syntax checks, never runtime verification.
    mach = directory / "mach"
    mach.mkdir()
    (mach / "mach_time.h").write_text(
        "#include <stdint.h>\n#include <time.h>\n"
        "typedef struct {uint32_t numer, denom;} mach_timebase_info_data_t;\n"
        "int mach_timebase_info(mach_timebase_info_data_t *);\n"
        "uint64_t mach_absolute_time(void);\n"
        "uint64_t mach_continuous_time(void);\n"
        "int mach_wait_until(uint64_t);\n"
        "uint64_t clock_gettime_nsec_np(clockid_t);\n"
        "#define CLOCK_UPTIME_RAW CLOCK_MONOTONIC\n"
        "typedef uintptr_t vm_address_t;\n"
        "unsigned int mach_task_self(void);\n"
        "int vm_deallocate(unsigned int, vm_address_t, size_t);\n")
    run(CC + ["-std=gnu11", "-Wall", "-Wextra", "-Werror=implicit-function-declaration",
              "-Werror=incompatible-pointer-types", "-fsyntax-only", "-DMAP_JIT=0",
              "-I" + str(directory)] + INCLUDES +
        [str(ROOT / "src/translation-layer/husk-tl-dex.c"),
         str(ROOT / "src/translation-layer/husk-tl-load.c"),
         str(ROOT / "src/translation-layer-next/husk-tl-jni-http.c"),
         str(ROOT / "src/translation-layer-next/husk-tl-jni-cocos.c")])
    print("PASS legacy DEX/loader and HTTP/Cocos JNI host syntax (Mach time declarations stubbed)")


def main():
    with tempfile.TemporaryDirectory(prefix="husk-security-") as temporary:
        directory = Path(temporary)
        test_dex(directory)
        test_xml(directory)
        test_xmem(directory)
        test_elf(directory)
        test_scripts()
        test_host_syntax(directory)
        run(CC + ["-std=gnu11", "-Wall", "-Wextra", "-Werror", "-fsyntax-only"] +
            INCLUDES + [str(ROOT / "src/translation-layer-next/husk-tl-ld.c")])
        planner = build(directory, "planner",
                        (ROOT / "tests/translation-layer/plan_test.c").read_text(),
                        [str(ROOT / "src/translation-layer/husk-tl-elf.c")])
        run([str(planner)])
    print("PASS host checks; NOT an Apple build, performance measurement or complete security verification")


if __name__ == "__main__":
    main()
