# النسخة المدمجة (Husk-merged)

الأساس: Husk-hardened-source. أضفنا إليه تحسينات الأداء من husk-optimized1.

## من hardened (أمان)
- cloud-init: إزالة كلمة المرور الثابتة، تعطيل SSH بكلمة مرور و root، إزالة الدخول التلقائي، منع حقن الأوامر (argv بدل shell).
- تقوية parsers: DEX, ELF/loader (جداول hash, relocations), binary XML, ZIP/gzip.
- AppSource: HTTPS فقط، حدود أحجام، منع downgrade في redirect.
- tests/security/test_hardening.py + docs/security-review.md

## من optimized (أداء وأخطاء)
- إيقاف glReadPixels الدوري، memcpy في ring buffer الصوت، جدول hash + كاش لـ GetMethodID.
- فك الأيقونات ونسخ APK وتحميل الكتالوج خارج main thread.
- إصلاحات: bql_lock المتكرر، تسريب JIT/FileHandle، sem_timedwait، sigset، ملكية الاستثناء في JNI.
- ملاحظات التغييرات التفصيلية: audit/

## ملفات دُمجت يدويًا (كانت متعارضة)
AppSource, ContentView, GuestImage, ld.c, xmem.c, dex.c, load.c: عند التعارض اعتُمدت نسخة hardened، وأُبقيت تعديلات optimized غير المتعارضة. أُزيل كود ميت نتج عن الدمج (دالة parse المكررة، متغيرين غير مستخدمين، معامل غير مستخدم في dex_code_in_file).

## ما تم التحقق منه
- اختبارات hardened الكاملة تنجح على النسخة المدمجة (DEX 10000 طفرة، XML، ELF، سكربتات).
- page planner ينجح، والماسح يبني بـ -Werror مع ASan/UBSan.
- لا أخطاء أو تحذيرات جديدة من gcc مقارنة بالنسختين الأصليتين.

## ما لم يُتحقق منه
- لا يوجد Swift compiler ولا Xcode ولا iPhone: كود Swift و Darwin اتراجع يدويًا فقط (توازن الأقواس سليم).
- لا قياس أداء حقيقي. لازم بناء في Xcode/CI وتجربة على جهاز قبل الاعتماد.
