المصدر داخل Husk/.
توثيق التصميم: Husk/docs/visual-redesign-ar.md
الفرق النصي: delivery/interface-changes.patch
نتائج الفحوص: delivery/test-results.txt
هذه نسخة مصدر وليست IPA. الأيقونات مدمجة بالفعل في asset catalogs وResources.
